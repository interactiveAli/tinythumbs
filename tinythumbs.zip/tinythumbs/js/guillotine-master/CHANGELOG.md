Changelog
=========

1.3.0
-----

**Features:**

- Make the cursor interactive when dragging.


**Bugfixes:**

- Fix dragging on IE 10 and 11 (#12).
- Fix image not being displayed on some browsers (#15).
- Fix drag not released with jQuery 1.8 (#16).
- Fix scale issue with the init option (#17).


1.2.2
-----

**Features:**

- Add Bower support (#7).


1.2.1
-----

**Bugfixes:**

- Fix zoom offsets (keep center when zooming).


1.2.0
-----

**Features:**

- Allow to set initial position and state.


1.1.0
-----

**Features:**

- Make the guillotine responsive.


1.0.0
-----

- Fully featured and working plugin.
